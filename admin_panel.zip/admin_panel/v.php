<?php 
    $var_personal_token = "ObKXBmfNj9lVOidkLF5UisGQawu0QrFT";
    $var_item_id = 40923472;
    $key = "05d0a43a34232da067f2db4e7335fe40770edc4a619f7e5eaf9a2ef5d9384a3a";
?>