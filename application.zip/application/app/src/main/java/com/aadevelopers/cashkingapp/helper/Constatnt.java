package com.aadevelopers.cashkingapp.helper;
public class Constatnt {

    //Admin url

    public static String Main_Url = "https://cash.hdcbbackground.com/"; //end with slash /
    public static String Base_Url = Main_Url+"api.php/";
    public static String WHEEL_URL = Main_Url+"img/wheel.gif";
    public static String RESET_PASSWORD = Main_Url+"reset_pass.php";
    public static String FORGOT_PASSWORD = Main_Url+"forget_pass.php";
    public static String WEBSITE_SETTINGS = Main_Url+"api/visit_settings.php";
    public static String VIDEO_SETTINGS = Main_Url+"api/video_settings.php";
    public static final String USER_LOGIN="user_login";
    public static final String ACCOUNT_STATE_ENABLED = "0";
    public static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    public static final String API="1";
    public static final String ACCESS_KEY="access_key";
    public static final String TASK="task";
    public static final String LEADER="leader";
    public static final String REWARD="reward";
    public static final String ACCESS_Value="05d0a43a34232da067f2db4e7335fe40770edc4a619f7e5eaf9a2ef5d9384a3a";
    public static final String NAME="name";
    public static final String USERNAME="username";
    public static final String EMAIL="email";
    public static final String FCM_ID="fcm_id";
    public static final String POINTS="points";
    public static final String REFER_CODE="refer";
    public static final String STATTUS="status";
    public static final String ID="id";
    public static final String GET_USER="get_user_by_id";
    public static final String USER_TRACKER="user_tracker";
    public static final String UPDATE_FCM="update_fcm_id";
    public static final String DAILY_CHECKIN_API="daily_checkin";
    public static final String ADD_SPIN="add_spin";
    public static final String SPIN_TYPE="type";
    public static final String GET_REFER_STATUS="get_refer_status";
    public static final String SET_REFER_STATUS="set_refer_status";
    public static final String REFER_CODE_STATUS="refer_code_status";
    public static final String REFER_STATUS="refer_status";
    public static final String DAILY_TYPE="Daily checkin bonus";
    public static final String REFER_TYPE="Refer & Earn";
}
