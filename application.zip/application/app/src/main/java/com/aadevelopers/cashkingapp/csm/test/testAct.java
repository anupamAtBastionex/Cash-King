package com.aadevelopers.cashkingapp.csm.test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.aadevelopers.cashkingapp.R;

public class testAct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
    }
}